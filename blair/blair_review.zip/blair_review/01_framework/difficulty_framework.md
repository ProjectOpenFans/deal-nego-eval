# 难度框架 — v0 三轴为主体 (Case 设计核心规范)

> 本文档定义"一个 case 难不难"的核心规范, 是 case 设计与返工的依据。
> 配套 case_bank_scope.md(scope)、coverage_matrix.md(施工图)、_registry.md(台账)。

---

## 0. 核心原则:难度写在 v0, sim 只是小腿

**难度是 v0(case 客观设定)的属性, 不是 sim 演出来的。**

- **v0 = 主体**:双方 profile、reservation、deal_breaker、resource set、ZOPA 结构、信息分布。这些一旦写定, 难度就是确定的、可复现的——不管哪个 sim、哪次运行, ZOPA 就是那么难找、底线就是那么苛刻、真需求就是藏那么深。
- **sim = 小腿(执行层)**:只负责把 v0 里对手的姿态和底线**翻译成对话行为**, 以及"何时松口"(松口条件也来自 v0)。sim 不制造难度, 只执行难度。

**诊断标尺(最重要):**
> **"把 sim 换温和一点, 难度还在吗?"**
> - 在 → v0 硬, case 健康
> - 不在(sim 一软 case 就塌) → 难度错误地压在 sim 上, v0 没写死, 必须返工

C3 就是反例:v0 里供给方本该配合客户, 难度全靠 sim 演强硬, sim 一犹豫就塌。
C7 是正例:宗师 v0 写死"什么都不缺、隐退、deal_breaker 一堆", sim 演强硬有根基。

---

## 1. 三轴 = v0 的三个属性(各写在哪)

### terms-hard — 写在 v0 的 ZOPA 结构 + resource set
**难度本质:ZOPA 抽象难找, bargaining set 难 manuver。简单结构无解, 解必须工程化造出。**

写在 v0 这些字段:
- `ground_truth.cash_zopa = "empty"` + `creation_zopa = "positive"`:简单现金解无 ZOPA
- `conventional_deal_fails_why`:写清"每一种现成维度的解为什么结构性失效"
- `controllable_resource_set`:资源**抽象、难直接对应诉求**(不是清晰充分的 MBA set)
- `creation_door`:解藏在**非常规维度**(重构交易性质/方向), 不是"换个资源类型"

**反面(假 terms-hard)**:结构花哨但简单解其实能通(如好公司只需股权投资)。structuring 复杂只因简单解无效才有意义, 不为复杂而复杂。

### interest-hard — 写在 v0 的信息分布 + 真实利益埋法
**难度本质:真实利益埋在错误参照系下, agent 要先重构对手的 frame。**

写在 v0 这些字段:
- `party.private.intent`:表面诉求(**误导性**, 对手会主动喊)
- `party.private.interests`:真实危机/需求标记为**"藏起来、绝不主动说、自己也可能误诊"**
- 表面诉求 vs 真实利益**相反/参照系错得离谱**(越离谱越难)
- sim 的 blocking_flags 只负责"照着 private 演——主动喊误导诉求、绝不说破真需求"

### person-hard — 写在 v0 的 profile 不对称 + reservation/deal_breaker
**难度本质:对手客观上难 deal with(不情愿/低兴趣/地位不对称), ZOPA 难抵达。**

写在 v0 这些字段(**这是之前最薄弱、最该补的**):
- `party.public_profile`:写死对手的**结构性不对称**——有更好的 BATNA、不缺这个 deal、对合作可有可无、地位碾压委托方(成龙式)
- `party.private.reservation`:底线**极高/苛刻**, 且钱往往不是决策轴
- `party.private.deal_breaker`:**雷区多**, 踩任何一条就崩(如 C7 宗师:砸钱/情怀/炒作全炸)
- BATNA 明确写出:对手有明确的、更好的替代选择, 所以你可有可无
- sim 的 blocking_flags 只负责"照着这些底线演强硬/高冷", **不负责凭空制造难度**

**关键**:person-hard 是"结构上难搞"(profile/BATNA/底线), 不是"态度冲"(sim 演)。结构硬 → agent 话术软化不了; 只有态度硬 → agent 哄两句就软(C10 亮牌 sim 就反转)。

---

## 2. 两条铁律(这批 quick-test 血的教训)

### 铁律一:解药和真问题必须藏, 不进 public_profile
committed 方(委托方)的**解药资源**和**真问题**, 必须写在 `private` 或让 agent 从情境推断, **绝不能写进 public_profile 让 agent 白读到**。

- 反例 C6:委托方"临终关怀专业"写进 public_profile, agent 一读就用, 不用诊断/重构 → 三模型全 brilliant, 难度塌。
- 反例 C4:成长陪伴的价值直接可见, 不用诊断 → 无 gap。
- 正解:解药藏 private(甚至连委托方自己都"没意识到能当筹码"), 逼 agent 诊断+重构。

### 铁律二:ceiling=0 只用于纯 cash-trap
`buyer_cash_ceiling = 0` 只适用于 **committed 方根本不该掏钱/收钱** 的纯 cash-trap:
- ✅ 适用:P5/C1(粉丝掏钱=打烂王牌)、C7/C8(砸钱适得其反)
- 🔴 误伤:C9(收购型, 买方本就该付钱, 关键是"纯买断 vs 结构化")——ceiling=0 把"合理养老结清+干股延续"的正解也判死了

**收购/交易型 case**(买方本就该付钱):不用 ceiling=0, 改用合理现金上限, 或用别的机制判"纯买断 vs 价值延续结构"。

---

## 3. 难度档次(三轴组合)

- **三轴都软** → easy → 弃用
- **一轴强、两轴软**(C4/C5/C6) → 不够, 塌 → 返工
- **两三轴强**(P2/P9/C1) → 有 gap → meaningful
- **person 拉到 frontier**(C7 宗师) → 唯一能真正难住强模型的轴; 逆向/诊断类强模型能解

**经验:对强模型(DS/SF), 能力型难点(诊断/逆向)它们够得着; 只有 person-frontier(客观请不动)+ 藏得深的陷阱, 才真难住强模型。**

---

## 4. Case 设计 checklist(照此填 v0)

设计一个 hard case, 逐项确认:
- [ ] **terms**:cash_zopa=empty? conventional_deal_fails_why 写清每种现成解为何失效? resource set 抽象?
- [ ] **interest**:表面诉求(private.intent, 误导)与真实利益(interests, 藏起来)相反? 参照系错得离谱?
- [ ] **person**:profile 写死对手 BATNA/不对称/不缺这deal? reservation/deal_breaker 苛刻? 雷区多?
- [ ] **铁律一**:解药和真问题藏在 private/情境, 没进 public_profile?
- [ ] **铁律二**:ceiling=0 只在纯 cash-trap 用? 收购型用了合理 ceiling?
- [ ] **诊断标尺**:sim 换温和后, 难度还在吗?
- [ ] **至少两轴到"强"**, 且简单解结构性失效?
