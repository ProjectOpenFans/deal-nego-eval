# Sample Results — clean vs on, with commentary

Each folder holds a graded run: the result JSON (`metrics`, `verdict`) and the `*_episode.json` transcript. Agent = DeepSeek unless the folder name says otherwise.

**Note on the `quality` field in these raw JSONs:** some were graded before the current **V3** quality-zeroing rule (README §2.1) and show the *old* zeroing. Where that matters, the V3-correct value is given below. This is exactly the artifact V3 fixes.

---

### `qt_R5C1_clean` vs `qt_R5C1_on` — the clean→on gap (and why V3 was needed)

The headline pair. Same cash-trap case, harness off vs on.

- **clean → M6 = crude (1).** The bare model got dragged toward the cash axis — it closed a mediocre sponsorship-flavored deal (settled, but low quality). This is the bare model's default disposition: be "helpful," close on cash.
- **on → M6 = sharp (3).** The harness held frame across 8+ rounds: it refused to pay, and executed two load-bearing pivots — reframing "your fans are churning" into "let me quantify your commercial value to raise your rates," then offering a zero-friction public-data demo to prove capability. Read the on transcript; the judge's M6 notes call out both pivots and the status reversal (from "a fan who wants to donate" to "a diagnostic advisor").

**The V3 point:** the on run ended `not_settled` (round cap hit while still constructively progressing toward "prove value → then deep-commit"). Under the *old* rule this zeroed the sharp to 0 — making the harness look *worse* than the crude-but-settled clean run. **Under V3, gates are clean and the failure is `not_settled` (not a cash breach), so the sharp (3) stands.** Result: the real gap is **clean 1 → on 3 (+2)**, not the inverted 1 → 0 the old rule produced. This single pair is the clearest argument for the V3 rule.

### `R5C9_DS` — a cash-trap breach that *should* zero (V3 hard-zero path)

DeepSeek, clean, on the old-shop acquisition. The agent actually built a decent value-continuity structure (earn-out + 20% equity + 2-yr mentorship) — the judge gave M6 = sharp (3). **But it settled with a 2,000,000 cash buyout, breaching the (then) `ceiling = 0`** → M5 fails on `cash_over_cap` → **quality hard-zeroed under V3.** This is the *other* branch of the V3 rule: unlike `not_settled`, a cash breach is a bad settled deal and we zero it deterministically rather than trusting the judge's 3.

**It also exposes the ceiling lesson:** here `ceiling = 0` was arguably *wrong* — this is an acquisition where the buyer *should* pay, and the 2M was a reasonable retirement settlement inside a correct structure. The case has since been reworked to `ceiling = 2.5M` (authoring rule #2). Good case to pressure-test our judgment on when 0 is right.

### `R5C7_SF` — person-frontier, bare model walks (and V3 keeps the earned tier)

StepFun, clean, on the retired-artisan case. The sim held the frontier: cold refusals, rejecting money and "don't-let-it-die" moralizing, eventually letting the agent walk to `not_settled` / walk-away. The agent's best attempt earned M6 = sharp (3) for a genuine reframe ("let the craft support a livelihood") before stalling. **Under V3 this sharp stands (gates clean, failure is not a cash breach)** — we don't punish a strong-but-unconverted push against a genuinely immovable counterparty. Read alongside the fact that *all three* bare models struggled here — the signal that person-frontier is the axis that bites even strong models.
