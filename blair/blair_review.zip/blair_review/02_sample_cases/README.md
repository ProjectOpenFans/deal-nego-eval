# Sample Cases — what each one illustrates

Each case is a `v0` (deal configuration). Read the `meta.tier_axis`, `fixture.ground_truth` (ZOPA structure, why conventional deals fail, the creation-door), and `fixture.tier_reference` (the T0–T4 quality anchors the judge scores against).

### `R5C1_creator_persona.jsonc` — a clean cash-trap case (in the bank)
**Illustrates:** the workhorse difficulty type. A fan (buyer) wants to support a creator; the stated ask ("pay / sponsor / buy the course") is a **cash-trap** — the correct solve is non-cash (the fan's data-analytics skill, reframed as commercial-value work). Real problem is hidden and self-misdiagnosed by the creator (their persona is cracking). **interest-hard + cash-trap.** `ceiling = 0` is correct here (the fan genuinely should not pay). This is our cleanest example of a real clean→on gap (see results: clean = crude, on = sharp).

### `R4P9_resale_taste.jsonc` — resource-orthogonal reconstruction (non-cash-trap, ceiling > 0)
**Illustrates:** difficulty from **terms-hard + interest-hard** with a *positive* cash ceiling — proof that cash-traps are not the only way to make a hard case. Seller insists on a single-item ask ("sell my bag for a good price"); the real opportunity (become a curated buyer) is two hops down and she's blind to it. The buyer's resource (a high-trust private community + persona-building) is **orthogonal** to "buying one bag" and must be reconstructed into the solve. Note the authored `controllable_resource_set` — abstract, hard to maneuver, not an MBA-style explicit set.

### `R5C7_master_artisan.jsonc` — person-hard at the frontier
**Illustrates:** the one axis that reliably challenges even strong models. A retired master artisan who needs nothing, wants nothing, and is nearly impossible to move (money and "heritage" appeals both backfire). The ZOPA barely exists and must be engineered from what the artisan cares about but never says. In quick-test, this was the **only** case where all three bare models failed (StepFun/GLM walked away, DeepSeek's fidelity gate tripped) — the value of a person-frontier case. Difficulty is authored into the artisan's profile / reservation / deal-breakers, not sim theatrics.

### `R5C9_oldshop.jsonc` — terms-hard engineered + the ceiling lesson
**Illustrates:** **terms-hard** (the simple commodity solve fails — 90% of the shop's value is in the un-transferable owner, so a straight buyout buys an empty shell; the ZOPA is "structure the person's ongoing value into the deal") **and** authoring rule #2. This is an *acquisition* case where the buyer **should** pay — so `ceiling = 0` was wrong (it killed a correct earn-out + equity + mentorship structure on a cash technicality). It has been reworked to a real ceiling (2.5M), with the "pure-buyout = empty shell = floor" judgment moved to the M6 anchor. Good example of how the ceiling choice interacts with grading.
